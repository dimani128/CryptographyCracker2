class Score:
    def __init__(self, filename):
        self.quadgram_freq = {}
        with open(filename, 'r') as file:
            for line in file:
                quadgram, frequency = line.strip().split()
                self.quadgram_freq[quadgram] = int(frequency)

    def score(self, text):
        text = text.upper()  # Convert text to uppercase for case-insensitive matching
        score = 0
        text_length = len(text)

        for i in range(text_length - 3):
            quadgram = text[i:i+4]
            if quadgram in self.quadgram_freq:
                score += self.quadgram_freq[quadgram]

        return score

# Example usage
if __name__ == '__main__':
    # Replace 'quadgram_frequency.txt' with the actual file containing quadgram frequencies
    quadgram_filename = 'quadgram_frequency.txt'
    text_to_score = "The quick brown fox jumps over the lazy dog."

    quadgram_scorer = Score(quadgram_filename)
    text_score = quadgram_scorer.score(text_to_score)
    print(f"Score for the text: {text_score}")
