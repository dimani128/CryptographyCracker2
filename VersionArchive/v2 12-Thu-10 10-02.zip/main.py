
import os
from ceaser import decryptCaesarCipher
from score import Score

__location__ = os.path.realpath(
    os.path.join(os.getcwd(), os.path.dirname(__file__)))

def maxd(dictionary):
    if not dictionary:
        return None

    largest_pair = None

    for key, value in dictionary.items():
        if largest_pair is None or value > largest_pair[1]:
            largest_pair = (key, value)

    return largest_pair

def location(path):
    return os.path.join(__location__, path)




score = Score(location('english_quadgrams.txt'))

with open(location('test.txt')) as f:
    text = f.read()

scores = {}
for i in range(26):
    txt = decryptCaesarCipher(text, i)
    scores[txt] = score.score(txt)

mx = maxd(scores)
print(f'Score: {mx[1]}, Text:\n-----\n{mx[0]}\n-----')